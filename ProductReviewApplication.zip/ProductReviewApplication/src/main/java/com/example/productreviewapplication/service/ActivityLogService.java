package com.example.productreviewapplication.service;

import com.example.productreviewapplication.model.ActivityLog;

public interface ActivityLogService {
    ActivityLog saveLog(ActivityLog log);
}
