package com.example.productreviewapplication.exception;

public class AopIsAwesomeHeaderException extends Exception{

    public AopIsAwesomeHeaderException(String message) {
        super(message);
    }
}
